echo g++ -O2 -o main main.cpp
g++ -O2 -o main main.cpp
echo ./main test
./main test
g++ -o main main.cpp
./main test